#Drew Remmenga
import random
from PIL import Image

def is_tie(useraction, computeraction):
    if useraction == computeraction:
        return True
    else:
        return False
def is_won(user_action, computer_action):
    if is_tie(user_action, computer_action):
        print(f"Both players selected {user_action}. It's a tie!")
    elif user_action == "rock":
        if computer_action == "scissors":
            print("Rock smashes scissors! You win!")
            image = Image.open('rockbeatsscissors.jpg')
            image.show()
        else:
            print("Paper covers rock! You lose.")
            image = Image.open('paperbeatsrock.jpg')
            image.show()
    elif user_action == "paper":
        if computer_action == "rock":
            print("Paper covers rock! You win!")
            image = Image.open('paperbeatsrock.jpg')
            image.show()
        else:
            print("Scissors cuts paper! You lose.")
            image = Image.open('scissorsbeatspaper.jpg')
            image.show()
    elif user_action == "scissors":
        if computer_action == "paper":
            print("Scissors cuts paper! You win!")
            image = Image.open('scissorsbeatspaper.jpg')
            image.show()
        else:
            print("Rock smashes scissors! You lose.")
            image = Image.open('rockbeatsscissors.jpg')
            image.show()

while True:
    user_action = input("Enter a choice (rock, paper, scissors): ")
    user_action=user_action.lower()
    possible_actions = ["rock", "paper", "scissors"]
    computer_action = random.choice(possible_actions)
    print(f"\nYou chose {user_action}, computer chose {computer_action}.\n")
    is_won(user_action, computer_action)
    play_again = input("Play again? (y/n): ")
    
    if play_again.lower() != "y":
        break
